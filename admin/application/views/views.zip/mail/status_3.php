<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Pembayaran Sudah Diterima</title>
</head>

<body>
<p>Dear, <?php echo $info->full_name ?></p>


<p>Pembayaran Anda untuk pesanan <b><?php echo $noorder?></b> telah kami konfirmasi.
Barang pesanan Anda selanjutnya akan masuk dalam proses pengemasan.</p>  
<p>Untuk memantau status pesanan Anda, silakan sign in ke excellent.com dan buka halaman Status Pemesanan.</p>
<p>Jika ada pertanyaan mengenai pesanan Anda silakan hubungi kami di cs@excellent.com.</p>


</body>
</html>