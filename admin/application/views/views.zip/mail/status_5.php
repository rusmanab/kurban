<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Proses Desain</title>
</head>

<body>
<p>Hallo, <?php echo $info->full_name ?></p>

<p>Pesanan anda sudah kami teruskan ke bagian desain. 
Silahkan berdiskusi dengan desainer kami, kunjungi halaman  
<a href="<?php echo site_url('order')?>"><?php echo site_url('order')?></a> </p>

<p>Terima kasih</p>
<p>Hormat Kami <br />
<a href="http://modelines.id/">Modelines.id</a>
</p>

</body>
</html>