<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Pengiriman</title>
</head>

<body>
<p>Dear, <?php echo $info->full_name ?></p>

<p>Barang Anda dengan pesanan <?php echo $noorder ?> telah selesai.  </p>
<p>Jika Anda belum menerima pesanan Anda silakan hubungi kami di cs@excellent.com </p>
<p>Terimakasih telah berbelanja di excellent.com</p>



</body>
</html>