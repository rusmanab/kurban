<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title><?php echo $title ?></title>
</head>

<body>
<p>Dear, <?php echo $info->full_name ?></p>

<p>Kami informasikan, bahwa pesanan anda dengan nomor order <b><?php echo $noorder?></b> sedang dalam proses pengiriman.</p>

<p>Terima kasih</p>
<p>Hormat Kami <br />
<a href="http://excellent.com/">excellent.com</a>

</p>

</body>
</html>