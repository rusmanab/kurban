<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Proses Pengukuran</title>
</head>

<body>
<p>Hallo, <?php echo $info->full_name ?></p>

<p>Pesanan anda dengan no <?php echo $noorder?>, sedang dalam pengemasan.
<p>Untuk memantau status pesanan Anda, silakan sign in ke excellent.com dan buka halaman Status Pemesanan.</p>
<p>Jika ada pertanyaan mengenai pesanan Anda silakan hubungi kami di cs@excellent.com.</p>
<a href="<?php echo site_url('order')?>">Status Pemesanan</a> </p>

<p>Terima kasih</p>
<p>Hormat Kami</p>

</body>
</html>