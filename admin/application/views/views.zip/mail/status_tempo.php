<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="lolkittens" />

	<title>Pembayaran Tempo</title>
</head>

<body>
<p>Dear, <?php echo $info->full_name ?></p>

<p>Pesanan anda dengan nomor <?php echo $noorder ?>, Jenis pembayaran Tempo telah di setujui.</p>
<p>
    <table>
        <tr>
            <td>Tempo</td>
            <td>: </td>
            <td>Tanggal Jatuh Tempo</td>
            <td>: </td>
        </tr>    
    <table>
</p>
<p>Terimakasih telah berbelanja di excellent.com</p>



</body>
</html>