<script type="text/javascript">

$(document).ready(function(e){
    $(".listcategory").select2();
    
});
</script>