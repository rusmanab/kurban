<script>
$(document).ready(function(e){
    $('.date-picker').datepicker({             
                orientation: "left",
                autoclose: true
             });
    
})
</script>